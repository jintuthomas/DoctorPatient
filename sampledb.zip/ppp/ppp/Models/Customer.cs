﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace ppp.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }
        [Required(ErrorMessage="can't empty")]
        [Display(Name="Customer Name")]
        public string cname { get; set; }
        [Required(ErrorMessage = "can't empty")]
        [Display(Name = "Customer Address")]
        public string caddress { get; set; }
        [Required(ErrorMessage = "can't empty")]
        [Display(Name = "Customer Email")]
        public string cemail { get; set; }
        [Required(ErrorMessage = "can't empty")]
        [Display(Name = "Customer username")]
        public string cusername { get; set; }
        [Required(ErrorMessage = "can't empty")]
        [Display(Name = "Customer Password")]
        public string cpassword { get; set; }



    }
}