﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ppp.Startup))]
namespace ppp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
