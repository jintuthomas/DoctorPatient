import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
   @Input() rollno:string;
   @Input() name:string;
   @Input() batch:string;
   @Input() dept:string;
   @Output() sendStudent:EventEmitter<any>=new EventEmitter();
  SelectStudent(){
    let selectedstudent:any={rollno:this.rollno,name:this.name,batch:this.batch,dept:this.dept};
    this.sendStudent.emit(selectedstudent);
  }


  constructor() { }

  ngOnInit() {
  }

}
