import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
  public StudentDetails:any=[{rollno:"1",name:"aaa",batch:"mca",dept:"computer"},
  {rollno:"2",name:"bbb",batch:"mca",dept:"computer"}];
  selstudent:any;
  addStudent(data:any){
  this.selstudent=data;
}

  constructor() { }

  ngOnInit() {
  }

}
