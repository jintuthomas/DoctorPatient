import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
public BookDetails:any=[{title:"Book 1",author:"Author 1",publisher:"Publisher 1"},{title:"Book 2",author:"Author 2",publisher:"Publisher 3"},
{title:"Book 3",author:"Author 3",publisher:"Publisher 3"}];
selbook:any;
addBook(data:any){
  this.selbook=data;
}
  constructor() { }

  ngOnInit() {
  }

}
