export class student{
    id:number;
        name:string;
        u_name:string;
        pword:string;
        status:number
    constructor(
       
    ){}
}