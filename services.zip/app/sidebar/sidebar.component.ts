import { Component, OnInit } from '@angular/core';
import {student} from '../student';
import { from } from 'rxjs';
import{NgForm} from '@angular/forms';
import{DemoService} from '../demo.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  student = new student();
  isRegisterd= false;

  constructor(private applyService:DemoService ) { }

  ngOnInit() {
  }
  registration(f:NgForm)
    {
    this.applyService.store(this.student).subscribe(data=>
      {
        this.isRegisterd=true;
        console.log("registered Sucessfully");
        f.reset;
    },
    (err)=>{this.isRegisterd=false});
   
    
  }  
  
}