import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
user:any;
check:boolean=true;
  constructor() {
    this.user={ name:'Jintu',
    job:'Sofrware Developer ',
   address:' Kannattukalayil',
    phone:['9400229661','9400933224','76543234']
};

   }
   togglecheck(){
     this.check=!this.check;
   }

  ngOnInit() {
  }

}
