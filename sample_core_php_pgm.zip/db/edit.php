<?php
include("dbcon.php");
$id=$_GET['id'];
$check=mysqli_query($con,"select * from student where id=$id");
$row=mysqli_fetch_array($check);							
?>
<table>
<form action="#" method="post">
<tr><th>Name&nbsp;</th><td><input type="text" name="txt1" value="<?php echo $row['name'];?>" /></td></tr><br>
<tr><th>Address&nbsp;</th><td><input type="text" name="txt2" value="<?php echo $row['address'];?>" /></td></tr><br>
<tr><th>Phone&nbsp;</th><td><input type="text" name="txt3" value="<?php echo $row['phone'];?>" /></td></tr>
<tr><td><input type="submit" name="submit" value="Save" /></td></tr>
</form>
</table>
<?php
if(isset($_POST['submit']))
{
$txt1=$_POST['txt1'];
$txt2=$_POST['txt2'];
$txt3=$_POST['txt3'];
mysqli_query($con,"update student set name='".$txt1."',address='".$txt2."',phone='".$txt3."' where id='".$id."'");
header("location:view.php");
}
?>