<?php
include("dbcon.php");
?>
<html>
<head></head>
<body>
<table>
<form action="action.php" method="post">
<tr><th>Name&nbsp;</th><td><input type="text" name="txt1" /></td></tr><br>
<tr><th>Address&nbsp;</th><td><input type="text" name="txt2" /></td></tr><br>
<tr><th>Phone&nbsp;</th><td><input type="text" name="txt3" /></td></tr>
<tr><td><input type="submit" name="submit" /></td></tr>
</form>
</table>
</body></html>
