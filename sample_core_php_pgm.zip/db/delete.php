<?php
include("dbcon.php");
$id=$_GET['id'];
$d=mysqli_query($con,"delete from student where id='$id'");
header("location:view.php");
?>
