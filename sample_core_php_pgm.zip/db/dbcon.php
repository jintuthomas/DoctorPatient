<?php 
$con=mysqli_connect("localhost","root","","db");
//mysqli_select_db($con,"dba");
/*if($con)
{
 echo "sucess";
 }
 else
 {
 echo "not sucess";
 }*/
?>


