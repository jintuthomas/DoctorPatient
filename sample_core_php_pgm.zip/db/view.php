<?php
include("dbcon.php");
$check=mysqli_query($con,"select  * from student");
							echo "<table border='2'>";
							echo "<tr><th>Name</th>
									   <th>Address</th>
									   <th>Phone</th>
									   <th>&nbsp;</th>
									   <th>&nbsp;</th>
									   </tr>";
							while($row=mysqli_fetch_array($check))
							{
							$id=$row['id'];
							echo "<tr><td>".$row['name']."</td>";
							echo "<td>".$row['address']."</td>";
							echo "<td>".$row['phone']."</td>";
							echo "<td><a href='edit.php?id=$row[id]'>Edit</a></td>";
							echo "<td><a href='delete.php?id=$row[id]'>Delete</a></td></tr>";

							}
		echo "</table>";

?>