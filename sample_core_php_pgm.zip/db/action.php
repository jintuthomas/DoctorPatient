<?php
include("dbcon.php");
if(isset($_POST['submit']))
{
$txt1=$_POST['txt1'];
$txt2=$_POST['txt2'];
$txt3=$_POST['txt3'];
mysqli_query($con,'insert into student(name,address,phone) values ("'.$txt1.'","'.$txt2.'","'.$txt3.'")');
$check=mysqli_query($con,"select  * from student");
							echo "<table border='2'>";
							echo "<tr><th>Name</th>
									   <th>Address</th>
									   <th>Phone</th>
									   <th>&nbsp;</th>
									   <th>&nbsp;</th>
									   </tr>";
							while($row=mysqli_fetch_array($check))
							{
							$id=$row['id'];
							echo "<tr><td>".$row['name']."</td>";
							echo "<td>".$row['address']."</td>";
							echo "<td>".$row['phone']."</td>";
							echo "<td><a href=''>Edit</a></td>";
							echo "<td><a href='delete.php?id=$row[id]'>Delete</a></td></tr>";

							}
		echo "</table>";
}
?>