<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Poly Clinic Medical Category Bootstrap Responsive website Template | Team :: w3layouts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Poly Clinic Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
</head>

<body>
    <!-- banner -->
    <div class="inner-banner" id="home">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">

                <h1>
                    <a class="navbar-brand text-white" href="index.html">
                        poly
                        <span>clinic</span>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item mr-3">
                            <a class="nav-link text-white" href="index.html">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item  mr-3">
                            <a class="nav-link text-white text-capitalize" href="about.html">about</a>
                        </li>
                        <li class="nav-item  mr-3">
                            <a class="nav-link text-white text-capitalize" href="services.html">services</a>
                        </li>
                        <li class="nav-item dropdown mr-3 active">
                            <a class="nav-link dropdown-toggle  text-white text-capitalize" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                Dropdown
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="gallery.html">Gallery</a>
                                <a class="dropdown-item" href="team.html">Team</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="typo.html">Typography</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link  text-white text-capitalize" href="contact.html">contact</a>
                        </li>
                    </ul>
                </div>

            </nav>
        </header>
        <!-- //header -->
        <!-- //container -->
    </div>
    <!-- breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.html">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Team</li>
        </ol>
    </nav>
    <!-- //breadcrumbs -->
    <!-- //banner -->
    <!-- team -->
    <section class="team-agile py-lg-5">
        <div class="container py-sm-5 pt-5 pb-0">
            <div class="title-section text-center pb-lg-5">
                <h4>world of medicine</h4>
                <h3 class="w3ls-title text-center text-capitalize">the medical staff</h3>
            </div>
            <div class="row mt-5 pb-lg-5">
                <div class="col-md-4 border p-0 my-auto">
                    <img src="images/t1.jpg" class="img-fluid" alt="team-img" />
                </div>
                <div class="col-md-8 team-text mt-md-0 mt-5">
                    <h4>Dr. Ed M.Calderon</h4>
                    <small>Orthopedician</small>
                    <p class="my-3">Donec consequat sapien ut leo cursus rhoncus.Quisque velit nisi, pretium ut lacinia in, elementum id
                        enim. Cras ultricies ligula Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla accumsan
                        ac elit in congue.</p>
                    <ul class="list-group mb-3">
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>Poly Clinic, Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>
                            Experience : 8+ years</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>
                            State : Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>USA</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-clock  mr-3"></i>
                            <span class="ot">MON - SAT : 11:00 AM - 1:00 PM , 1:00 PM - 4:00 PM </span>
                        </li>
                    </ul>
                    <a href="#" class="btn_apt" data-toggle="modal" data-target="#exampleModalLabel2">make an appointment </a>
                </div>
            </div>
            <div class="row my-5 py-lg-5">
                <div class="col-md-8 team-text  order-1 order-sm-0  mt-md-0 mt-5">
                    <h4>Dr. Simone L</h4>
                    <small>Pediatrician</small>
                    <p class="my-3">Donec consequat sapien ut leo cursus rhoncus.Quisque velit nisi, pretium ut lacinia in, elementum id
                        enim. Cras ultricies ligula Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla accumsan
                        ac elit in congue.</p>
                    <ul class="list-group mb-3">
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>Poly Clinic, Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>
                            Experience : 8+ years</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>
                            State : Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>USA</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-clock  mr-3"></i>
                            <span class="ot">MON - SAT : 11:00 AM - 1:00 PM , 1:00 PM - 4:00 PM </span>
                        </li>
                    </ul>
                    <a href="#" class="btn_apt" data-toggle="modal" data-target="#exampleModalLabel2">make an appointment </a>
                </div>
                <div class="col-md-4 border p-0 my-auto order-0 order-sm-1">
                    <img src="images/t2.png" class="img-fluid" alt="team-img" />
                </div>
            </div>
            <div class="row py-lg-5 mb-5">
                <div class="col-md-4 border p-0 my-auto">
                    <img src="images/t3.png" class="img-fluid" alt="team-img" />
                </div>
                <div class="col-md-8 team-text mt-md-0 mt-5">
                    <h4>Dr. Ed M.Carter</h4>
                    <small>NeuroPoly Clinic</small>
                    <p class="my-3">Donec consequat sapien ut leo cursus rhoncus.Quisque velit nisi, pretium ut lacinia in, elementum id
                        enim. Cras ultricies ligula Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla accumsan
                        ac elit in congue.</p>
                    <ul class="list-group mb-3">
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>Poly Clinic, Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>
                            Experience : 8+ years</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>
                            State : Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>USA</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-clock  mr-3"></i>
                            <span class="ot">MON - SAT : 11:00 AM - 1:00 PM , 1:00 PM - 4:00 PM </span>
                        </li>
                    </ul>
                    <a href="#" class="btn_apt" data-toggle="modal" data-target="#exampleModalLabel2">make an appointment </a>
                </div>
            </div>
            <div class="row my-5 py-lg-5 mb-md-0 mb-5">
                <div class="col-md-8 team-text order-1 order-sm-0  mt-md-0 mt-5">
                    <h4>Dr. P.Smith</h4>
                    <small>Cardiologist
                    </small>
                    <p class="my-3">Donec consequat sapien ut leo cursus rhoncus.Quisque velit nisi, pretium ut lacinia in, elementum id
                        enim. Cras ultricies ligula Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla accumsan
                        ac elit in congue.</p>
                    <ul class="list-group mb-3">
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>Poly Clinic, Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>
                            Experience : 30 years</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-check-square  mr-3"></i>
                            State : Newyork</li>
                        <li class="list-group-item border-0 py-0">
                            <i class="far fa-check-square  mr-3"></i>USA</li>
                        <li class="list-group-item border-0">
                            <i class="far fa-clock  mr-3"></i>
                            <span class="ot">MON - SAT : 11:00 AM - 1:00 PM , 1:00 PM - 4:00 PM </span>
                        </li>
                    </ul>
                    <a href="#" class="btn_apt" data-toggle="modal" data-target="#exampleModalLabel2">make an appointment </a>
                </div>
                <div class="col-md-4 border p-0 my-auto order-0 order-sm-1">
                    <img src="images/t4.jpg" class="img-fluid" alt="team-img" />
                </div>
            </div>
        </div>
    </section>
    <!-- //team -->
    <!-- footer -->
    <footer class="footer py-md-5 pt-md-3 pb-sm-5">
        <div class="footer-position">
            <div class="container">
                <div class="row newsletter-inner">
                    <div class="col-md-4 py-3">
                        <h3 class="w3ls-title text-white">
                            Get notified</h3>
                        <p class="text-white">sociosqu ad litora torquent per conubia.</p>
                    </div>
                    <div class="col-md-8 newsright">
                        <form action="#" method="post" class="d-flex">
                            <input class="form-control" type="email" placeholder="Enter your email..." name="email" required="">
                            <input class="form-control" type="submit" value="Subscribe">
                        </form>
                    </div>
                    <div class="up-arrow"></div>
                </div>
            </div>
        </div>
        <div class="container-fluid py-lg-5 mt-sm-5">
            <div class="row p-sm-4 px-3 py-5">
                <div class="col-lg-4 col-md-6 footer-top mt-lg-0 mt-md-5">
                    <h2>
                        <a href="index.html" class="text-theme text-uppercase">
                            poly clinic
                        </a>
                    </h2>
                    <p class="mt-2">Donec consequat sam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus
                        id quod possimusapien ut leo cursus rhoncus. Nullam dui mi, vulputate ac metus at, semper varius
                        orci.
                    </p>
                </div>
                <div class="col-lg-2  col-md-6 mt-lg-0 mt-5">
                    <div class=".footerv2-w3ls">
                        <h3 class="mb-3 w3f_title">Navigation</h3>
                        <hr>
                        <ul class="list-agileits">
                            <li>
                                <a href="index.html">
                                    Home
                                </a>
                            </li>
                            <li class="my-2">
                                <a href="about.html">
                                    About Us
                                </a>
                            </li>
                            <li class="my-2">
                                <a href="gallery.html">
                                    Gallery
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="services.html">
                                    Services
                                </a>
                            </li>
                            <li>
                                <a href="contact.html">
                                    Contact Us
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-lg-0 mt-5">
                    <div class="footerv2-w3ls">
                        <h3 class="mb-3 w3f_title">Contact Us</h3>
                        <hr>
                        <div class="fv3-contact">
                            <span class="fas fa-envelope-open mr-2"></span>
                            <p>
                                <a href="mailto:example@email.com">info@example.com</a>
                            </p>
                        </div>
                        <div class="fv3-contact my-2">
                            <span class="fas fa-phone-volume mr-2"></span>
                            <p>+456 123 7890</p>
                        </div>
                        <div class="fv3-contact">
                            <span class="fas fa-home mr-2"></span>
                            <p>+90 nsequursu dsdesdc,
                                <br>xxx Street State 34789.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-lg-0 mt-5">
                    <div class="footerv2-w3ls">
                        <h3 class="mb-3 w3f_title">Links</h3>
                        <hr>
                        <ul class="list-agileits">
                            <li>
                                <a href="index.html">
                                    Overview
                                </a>
                            </li>
                            <li class="my-2">
                                <a href="services.html">
                                    Centres of Excellence
                                </a>
                            </li>
                            <li class="my-2">
                                <a href="single.html">
                                    Blog
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="contact.html">
                                    Find us
                                </a>
                            </li>
                            <li>
                                <a href="index.html">
                                    Privacy Policy
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- //footer bottom -->
    </footer>
    <!-- //footer -->
    <!-- quick contact -->
    <div class="container">
        <div class="outer-col">
            <div class="heading">Quick Enquiry</div>
            <div class="form-col">
                <form action="#" method="post">
                    <input type="text" class="form-control" placeholder="Name" name="Name" id="user-name" required="">
                    <input type="email" class="form-control" placeholder="Email" name="Name" id="Email-id" required="">
                    <input type="text" class="form-control" placeholder="phone number" name="Name" id="phone-number" required="">
                    <textarea placeholder="your message" class="form-control"></textarea>
                    <input type="submit" value="send" class="btn_apt">
                </form>
            </div>
        </div>
    </div>
    <!-- //quick contact -->
    <!-- copyright -->
    <div class="cpy-right text-center">
        <p>© 2018 Poly Clinic. All rights reserved | Design by
            <a href="http://w3layouts.com"> W3layouts.</a>
        </p>
    </div>
    <!-- //copyright -->
    <!-- //Appointment modal -->
    <div class="modal fade" id="exampleModalLabel2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Fill details below to make an appointment</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="wthree-info">

                        <div class="login">
                            <form action="#" method="post">
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Patient name</label>
                                    <input type="text" class="form-control" placeholder=" " name="Name" id="recipient-name" required="">
                                </div>
                                <div class="form-group">
                                    <label for="recipient-phone" class="col-form-label">Phone</label>
                                    <input type="text" class="form-control" placeholder=" " name="Name" id="recipient-phone" required="">
                                </div>
                                <div class="form-group">
                                    <label for="datepicker" class="col-form-label">Choose Date of Appointment</label>
                                    <input placeholder="Date" class="date form-control" id="datepicker" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"
                                        required="" />
                                </div>
                                <div class="form-group">
                                    <select required="" class="form-control">
                                        <option value="">Select Time</option>
                                        <option value="1">08:00-8:30</option>
                                        <option value="2">08:30-9:00</option>
                                        <option value="3"> 09:00-9:30</option>
                                        <option value="4">09:30-10:00</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select required="" class="form-control">
                                        <option value="">Select City</option>
                                        <option value="1">city1</option>
                                        <option value="2">city2</option>
                                        <option value="3"> city3</option>
                                        <option value="4">city4</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select required="" class="form-control">
                                        <option value="">Select Hospital/Clinic</option>
                                        <option value="1">Hospital1</option>
                                        <option value="2">Hospital2</option>
                                        <option value="3">Hospital3</option>
                                        <option value="4">Hospital4</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select required="" class="form-control">
                                        <option value="">Select Speciality</option>
                                        <option value="1">Dermatology</option>
                                        <option value="2">ENT</option>
                                        <option value="3"> Genaral Medicine</option>
                                        <option value="4">Nutritionist</option>
                                    </select>
                                </div>
                                <input type="submit" value="Request Appointment" class="btn_apt">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //Appointment modal -->
    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- //fixed quick contact -->
    <script>
        $(function () {
            var hidden = true;
            $(".heading").click(function () {
                if (hidden) {
                    $(this).parent('.outer-col').animate({
                        bottom: "0"
                    }, 1200);
                } else {
                    $(this).parent('.outer-col').animate({
                        bottom: "-305px"
                    }, 1200);
                }
                hidden = !hidden;
            });
        });
    </script>
    <!-- //fixed quick contact -->
    <!--start-date-piker-->
    <link rel="stylesheet" href="css/jquery-ui.css" />
    <script src="js/jquery-ui.js"></script>
    <script>
        $(function () {
            $("#datepicker,#datepicker1").datepicker();
        });
    </script>
    <!-- //End-date-piker -->
    <!-- start-smooth-scrolling -->
    <script src="js/easing.js"></script>
    <script>
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();

                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <script src="js/SmoothScroll.min.js"></script>
    <!-- //end-smooth-scrolling -->
    <!-- Bootstrap core JavaScript
================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>

</html>