<?php

namespace App\Http\Controllers;

use App\tbl_Doctor;
use Illuminate\Http\Request;
use DB;
use Storage;
class TblDoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $add_doctor=tbl_Doctor::all();
	  return view('Admin.ViewDoctor',compact('add_doctor'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		 $photo=$request->file('photo');
		 
		$filename= $request->photo->getClientOriginalName();
		//Storage::put('public\upload\',$filename,file_get_contents($request->file('photo')->getRealPath()));
       $request->photo->storeAs('public/upload',$filename);
        $uname=$request->input('email');
		 $check=DB::table('tbl__doctors')->where(['email'=>$uname])->get();
		 
		 if(count($check)==0)		
		{
                         $users=new tbl_Doctor([
						 'd_name'=>$request->get('d_name'),
	                     'surname'=>$request->get('surname'),
						 'dob'=>$request->get('dob'),	
						 'gender'=>$request->get('gender'),										 
						 'specilalization'=>$request->get('specilalization'),						 
						 'h_name'=>$request->get('h_name'),
						 'street'=>$request->get('street'),
		                 'city'=>$request->get('city'),						 
						 'state'=>$request->get('state'),
						 'country'=>$request->get('country'),
                    	 'zip'=>$request->get('zip'),
						 'email'=>$request->get('email'),
						  'pwd'=>$request->get('pwd'),
		                 'phone'=>$request->get('phone'),						 
						 'quali'=>$request->get('quali'),
						 'y_exp'=>$request->get('y_exp'),
                    	 'emp_history'=>$request->get('emp_history'),
						  'fee'=>$request->get('fee'),
						  'photo'=>$filename,
						  'status'=>'1'
		                   ]);
		$users->save();
		$d_name=$request->input('d_name');
		$pwd=$request->input('pwd');
		
			$result=DB::insert("insert into logins(name,username,password,role,status)values(?,?,?,?,?)",[$d_name,$uname,$pwd,2,1]);
			//$add_doctor=TblDoctor::all();
	       // return view('ViewDoctor',compact('add_doctor'));
			return view('Admin.addDoctor1');
			
			
		}
		else
		{
			return view('Admin.addDoctor1');
			echo "Already exist";
		}
	}
		

    /**
     * Display the specified resource.
     *
     * @param  \App\tbl_Doctor  $tbl_Doctor
     * @return \Illuminate\Http\Response
     */
    public function show(tbl_Doctor $tbl_Doctor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\tbl_Doctor  $tbl_Doctor
     * @return \Illuminate\Http\Response
     */
    public function edit(tbl_Doctor $tbl_Doctor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\tbl_Doctor  $tbl_Doctor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tbl_Doctor $tbl_Doctor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\tbl_Doctor  $tbl_Doctor
     * @return \Illuminate\Http\Response
     */
   
	public function destroy($id)
    {
		DB::delete('delete from tbl__doctors where id = ?',[$id]);
		//return view('Admin.ViewDoctor');
		return redirect("ViewDoctor");
       
        
    }
}
