<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_Doctor extends Model
{
     public $fillable=['d_name','surname','dob','gender','specilalization','h_name','street','city','state','country','zip','email','pwd','phone','quali','y_exp','emp_history','fee','photo','status'];

}
