<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
       public $fillable=['d_name','passsword','email','photo'];

}
