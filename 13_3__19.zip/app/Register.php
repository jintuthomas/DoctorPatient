<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    public $fillable=['p_name','email','password','gender','dob','phone','h_name','street','district','state','country','role','status'];
}
